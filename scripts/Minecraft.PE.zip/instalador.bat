@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title CRACKLOOP - Instalador

:: ============================================================
:: VERIFICA ADMINISTRADOR
:: ============================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: ============================================================
:: CONFIGURAÇÕES
:: ============================================================

set "ORIGEM=%~dp0"
set "MINECRAFT_ROAMING=%APPDATA%\Minecraft Bedrock"

:: ============================================================
:: PAINEL INICIAL
:: ============================================================

cls
color 0B

echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║                                      ║
echo              ║            CRACKLOOP                 ║
echo              ║                                      ║
echo              ║----------DESBLOQUEANDO---------------║
echo              ║                                      ║
echo              ╚══════════════════════════════════════╝
echo.
echo.
echo                    Inicializando...
echo.

:: ============================================================
:: BARRA DE CARREGAMENTO - 7 SEGUNDOS
:: ============================================================

set "bar="

for /L %%P in (0,5,100) do (
    set /a "blocks=%%P/5"
    set "bar="

    for /L %%B in (1,1,!blocks!) do (
        set "bar=!bar!█"
    )

    for /L %%B in (!blocks!,1,20) do (
        set "bar=!bar!░"
    )

    cls
    color 0B

    echo.
    echo.
    echo              ╔══════════════════════════════════════╗
    echo              ║                                      ║
    echo              ║             CRACKLOOP                ║
    echo              ║                                      ║
    echo              ║-----------DESBLOQUEANDO--------------║
    echo              ║                                      ║
    echo              ╚══════════════════════════════════════╝
    echo.
    echo.
    echo                    Carregando...
    echo.
    echo                 [!bar!] %%P%%
    echo.

    timeout /t 1 /nobreak >nul
)

:: ============================================================
:: VERIFICA DLL 1
:: ============================================================

cls
echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║            CRACKLOOP                 ║
echo              ╚══════════════════════════════════════╝
echo.
echo              [1/4] Verificando arquivos...
echo.

if not exist "%ORIGEM%vcruntime140_1.dll" (
    color 0C
    echo              [ERRO]
    echo.
    echo              vcruntime140_1.dll nao encontrada.
    echo.
    echo              Coloque a DLL na mesma pasta do
    echo              instalar.bat.
    echo.
    pause
    exit /b 1
)

if not exist "%ORIGEM%KG-UP-GOAT.dll" (
    color 0C
    echo              [ERRO]
    echo.
    echo              KG-UP-GOAT.dll nao encontrada.
    echo.
    echo              Coloque a DLL na mesma pasta do
    echo              instalar.bat.
    echo.
    pause
    exit /b 1
)

echo              [OK] Arquivos encontrados.
timeout /t 1 /nobreak >nul

:: ============================================================
:: PROCURA A INSTALAÇÃO DO MINECRAFT
:: ============================================================

cls
echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║============CRACKLOOP=================║ 
echo              ╚══════════════════════════════════════╝
echo.
echo              [2/4] Procurando Minecraft Bedrock...
echo.

set "MINECRAFT_APP="

for /d %%D in ("C:\Program Files\WindowsApps\Microsoft.MinecraftUWP_*_x64__8wekyb3d8bbwe") do (
    set "MINECRAFT_APP=%%~D"
)

if not defined MINECRAFT_APP (
    color 0C
    echo              [ERRO]
    echo.
    echo              Minecraft Bedrock nao encontrado.
    echo.
    echo              Verifique se o Minecraft esta instalado
    echo              pela Microsoft Store/Xbox.
    echo.
    pause
    exit /b 1
)

echo              [OK] Minecraft encontrado.
echo.
echo              Pasta detectada:
echo              !MINECRAFT_APP!
timeout /t 2 /nobreak >nul

:: ============================================================
:: COPIA DLL 1
:: ============================================================

cls
echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║============CRACKLOOP=================║
echo              ╚══════════════════════════════════════╝
echo.
echo              [3/4] Instalando vcruntime140_1.dll...
echo.

copy /Y "%ORIGEM%vcruntime140_1.dll" "!MINECRAFT_APP!\" >nul

if errorlevel 1 (
    color 0C
    echo              [ERRO] Falha ao copiar DLL 1.
    echo.
    pause
    exit /b 1
)

echo              [OK] vcruntime140_1.dll instalada.
timeout /t 1 /nobreak >nul

:: ============================================================
:: CRIA MODS E COPIA DLL 2
:: ============================================================

cls
echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║==============CRACKLOOP===============║
echo              ╚══════════════════════════════════════╝
echo.
echo              [4/4] Instalando KG-UP-GOAT.dll...
echo.

if not exist "%MINECRAFT_ROAMING%\mods" (
    mkdir "%MINECRAFT_ROAMING%\mods"
)

if not exist "%MINECRAFT_ROAMING%\mods" (
    color 0C
    echo              [ERRO] Nao foi possivel criar a pasta mods.
    echo.
    pause
    exit /b 1
)

copy /Y "%ORIGEM%KG-UP-GOAT.dll" "%MINECRAFT_ROAMING%\mods\" >nul

if errorlevel 1 (
    color 0C
    echo              [ERRO] Falha ao copiar DLL 2.
    echo.
    pause
    exit /b 1
)

echo              [OK] KG-UP-GOAT.dll instalada.
timeout /t 1 /nobreak >nul

:: ============================================================
:: FINAL
:: ============================================================

cls
color 0A

echo.
echo.
echo              ╔══════════════════════════════════════╗
echo              ║                                      ║
echo              ║=========crackloop====================║
echo              ║                                      ║
echo              ║        INSTALACAO CONCLUIDA          ║
echo              ║   obrigado pela preferencia, amigo!  ║
echo              ╚══════════════════════════════════════╝
echo.
echo.
echo              [OK] vcruntime140_1.dll
echo              [OK] KG-UP-GOAT.dll
echo              [OK] Pasta mods criada/verificada
echo.
echo              Tudo foi instalado com sucesso.
echo.
echo              Pressione qualquer tecla para sair...
echo.

pause >nul
exit /b 0